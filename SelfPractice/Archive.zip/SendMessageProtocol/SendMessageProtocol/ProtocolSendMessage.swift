//
//  ProtocolSendMessage.swift
//  SendMessageProtocol
//
//  Created by Chandnani, Harsh on 2/13/22.
//

import Foundation

protocol SendMessageDelegate {
    func sendMessage(message : String)
}
