//
//  URLs.swift
//  PromisesExample
//
//  Created by Chandnani, Harsh on 3/6/22.
//

import Foundation

let urlShortQuote = "https://financialmodelingprep.com/api/v3/quote-short/FB?apikey=33deb196dce3edc9a75e1369665793e4"
