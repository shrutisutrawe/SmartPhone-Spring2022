//
//  ViewController.swift
//  SearchBarExample
//
//  Created by Chandnani, Harsh on 3/6/22.
//

import UIKit

class ViewController: UIViewController,UITableViewDelegate, UITableViewDataSource, UISearchBarDelegate{
    
    var namesArray = ["Shruti","Mark","John","Mike","Ross","Joe"]

    var copyArray = ["Shruti","Mark","John","Mike","Ross","Joe"]
    
    @IBOutlet weak var tblView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return namesArray.count;
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath);
        
        cell.textLabel?.text = namesArray[indexPath.row];
        
        return cell;
        
    }

    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        
        
        guard !searchBar.text!.isEmpty else{ //if search bar text is not empty proceed else restore original array
            namesArray = copyArray
            tblView.reloadData()
            return
        }
        
        namesArray = copyArray.filter({ name in
            name.lowercased().contains(searchBar.text!.lowercased())
        })
        
        tblView.reloadData()
    }
    
}

