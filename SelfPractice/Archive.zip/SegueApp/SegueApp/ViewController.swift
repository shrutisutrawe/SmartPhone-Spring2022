//
//  ViewController.swift
//  SegueApp
//
//  Created by Chandnani, Harsh on 2/12/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var txtFrstName: UITextField!
    @IBOutlet weak var txtLastName: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func goToSecondVC(_ sender: Any) {
        performSegue(withIdentifier: "SegueToSecondVC", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "SegueToSecondVC" {
            
            let secondVC = segue.destination as! SecondViewController
            secondVC.welcomeStr = "Welcome \(txtFrstName.text!) , \(txtLastName.text!)"
        }
        
    }
}

