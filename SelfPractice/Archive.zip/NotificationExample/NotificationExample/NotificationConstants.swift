//
//  NotificationConstants.swift
//  NotificationExample
//
//  Created by Chandnani, Harsh on 2/13/22.
//

import Foundation

let nameNotification = "edu.northeastern.shruti.nameNotification"
