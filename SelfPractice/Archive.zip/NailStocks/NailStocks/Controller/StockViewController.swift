//
//  StockViewController.swift
//  NailStocks
//
//  Created by Chandnani, Harsh on 2/20/22.
//

import UIKit

class StockViewController: UIViewController {

    @IBOutlet var txtStockSymbol: UIView!
    @IBOutlet weak var lblStockPrice: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func getStockPrice(_ sender: Any) {
        let symbol = txtStockSymbol.text!
        let url = "\(shortQuoteURL)\(symbol)?apikey=\(apiKeys)"
        print(url)
        
        AF.request(url).responseJSON{
            response in
            if response.error != nil{
                print(response.error!)
                return
            }
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
