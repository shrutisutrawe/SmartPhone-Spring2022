//
//  ViewController.swift
//  NailStocks
//
//  Created by Chandnani, Harsh on 2/20/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

