//
//  StockShort.swift
//  StockMaster1
//
//  Created by Chandnani, Harsh on 3/9/22.
//

import Foundation
import RealmSwift


class StockShort : Object{
    @objc dynamic var symbol: String = ""
    @objc dynamic var price: Float = 0.0
    @objc dynamic  var volume: Int = 0
    
    override static func primaryKey() -> String? {
        return "symbol"
    }
}
