//
//  URLs.swift
//  StockMaster1
//
//  Created by Chandnani, Harsh on 3/9/22.
//

import Foundation

let shortQuote = "https://financialmodelingprep.com/api/v3/quote-short/"
