//
//  StockMasterViewController.swift
//  StockMaster1
//
//  Created by Chandnani, Harsh on 3/9/22.
//

import UIKit
import SwiftUI
import SwiftyJSON
import SwiftSpinner
import Alamofire
import PromiseKit
import RealmSwift

class StockMasterViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
//        print (Realm.Configuration.defaultConfiguration.fileURL!)
        loadStockValues()

        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func addToDatabase(_ sender: Any) {
        
        let stock = StockShort()
        stock.symbol = "AAPL"
        stock.price = 206.6756
        stock.volume = 15456
        do {
            let realm = try Realm()
            
            try realm.write({
                realm.add(stock, update: .modified)
            })
        }catch{
            print("Error in writing to  DB")
        }
    }
    
    
    
    func getTSLAStock() -> StockShort{
        do {
            let realm = try Realm()
            let stocks = realm.objects(StockShort.self)
            print("printing stock values")
//            print(stocks)
            
            for stock in stocks {
                print(stock.symbol)
                if stock.symbol ==  "TSLA"{
                    return stock
                }
            }
            
        }catch{
            print("Error in reading from DB")
        }
        return StockShort()
    }
    
    func loadStockValues(){
        do {
            let realm = try Realm()
            let stocks = realm.objects(StockShort.self)
            print("printing stock values")
//            print(stocks)
            
            for stock in stocks {
                print(stock.symbol)
            }
        }catch{
            print("Error in reading from DB")
        }
    }
    
    
    func deleteStockFromDB(stock : StockShort){
        do{
            let realm = try Realm()
            try realm.write({
                realm.delete(stock)
            })

        }catch{
            print("Unable to delete from DB")
        }
    }
    
    @IBAction func deleteStock(_ sender: Any) {
        let tsla = getTSLAStock()

//        tsla.symbol = "TSLA"
        deleteStockFromDB(stock: tsla)
        
    }
    
    func addStockToDB(symbol : String){
        let stock = StockShort()
        stock.symbol = symbol
        
        do {
            let realm = try Realm()
            
            try realm.write({
                realm.add(stock, update: .modified)
            })
        }catch{
            print("Error in writing to  DB")
        }
    }
    
    @IBAction func addStocks(_ sender: Any) {
        
        var txtField: UITextField?
        
        let alertController = UIAlertController(title: "Add Stock", message: "", preferredStyle: .alert)
        
        let OKButton = UIAlertAction(title: "OK", style: .default) { action in
            guard let symbol = txtField?.text else{
                return
            }
            self.addStockToDB(symbol: symbol)
        }
        let CancelButton = UIAlertAction(title: "Cancel", style: .cancel) { action in
            
        }
        alertController.addAction(OKButton)
        alertController.addAction(CancelButton)
        
        alertController.addTextField{ stockTextField in
            stockTextField.placeholder = "Type Stock Symbol"
            txtField = stockTextField
        }
        
        self.present(alertController, animated: true, completion: nil)
        
    }
}
