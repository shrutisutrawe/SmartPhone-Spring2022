//
//  StockViewController.swift
//  StockMaster
//
//  Created by Chandnani, Harsh on 3/6/22.
//

import UIKit

class StockViewController: UIViewController {

    let stockArr = ["FB","TSLA","MSFT","AAPL"]
    
    var stockData: [QuoteShort] = []
    
    @IBOutlet weak var tblView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        loadStockData()
        // Do any additional setup after loading the view.
    }
    

    

}
