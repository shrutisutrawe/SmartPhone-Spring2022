//
//  ViewController.swift
//  TakeAPictureExample
//
//  Created by Chandnani, Harsh on 3/13/22.
//

import UIKit

/*
 Steps for Localization
 1. Add a Localizable.strings file
 2. Click on Localizable on the right menu for the localizable file
 3. Click on Project in the left side top -> Info
 4. Add the language you want from the localizable
 5. Your localizable file would add that language file
 6. Create Key value pair for all the strings you need to localize for e.g  "take_pic" = "Take a Picture";, "take_pic" = "एक तस्वीर ले लो ";
 7. remeber to add a semi colon to the end
 8. Create a Utilities folder and add a swift file called LocalizationUtil
 9. Create variable for the key like var strTakePic = NSLocalizedString("take_pic", comment: "")
10. In the viewDidLoad or separate function get the localized string and st the title as btnTakePic.setTitle(strTakePic, for: .normal)
 11. Change the language in the setting of the Phone
 12. Run the app and see the changes
 
 */

class ViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    @IBOutlet weak var imgView: UIImageView!
    
    @IBOutlet weak var btnTakePic: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        btnTakePic.setTitle(strTakePic, for: .normal)
        // Do any additional setup after loading the view.
    }

    @IBAction func takePictureAction(_ sender: Any) {
        
        let alertController = UIAlertController(title: "Take a Picture", message: "Select Image from Library or take a picture", preferredStyle: .alert)
        
        let cameraAction = UIAlertAction(title: "Camera", style: .default) { action in
            print("I am in Camera")
            if UIImagePickerController.isSourceTypeAvailable(.camera){
                let imagePicker = UIImagePickerController()
                imagePicker.delegate = self
                imagePicker.sourceType = UIImagePickerController.SourceType.camera
                imagePicker.allowsEditing = false
                self.present(imagePicker, animated: true, completion: nil)
                
            }
        }
        
        let libraryAction = UIAlertAction(title: "Photo Library", style: .default) { action in
            print("I am in Photo Library")
            if UIImagePickerController.isSourceTypeAvailable(.photoLibrary){
                let imagePicker = UIImagePickerController()
                imagePicker.delegate = self
                imagePicker.sourceType = UIImagePickerController.SourceType.photoLibrary
                imagePicker.allowsEditing = false
                self.present(imagePicker, animated: true, completion: nil)
                
            }
        }
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel) { action in
            print("Cancel")
        }
        
        alertController.addAction(cameraAction)
        alertController.addAction(libraryAction)
        alertController.addAction(cancelAction)
        
        self.present(alertController, animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        guard let image = info[UIImagePickerController.InfoKey.originalImage] as? UIImage else {
            picker.dismiss(animated: true, completion: nil)
            return
        }
        
        imgView.image = image
        picker.dismiss(animated: true, completion: nil)
        
        
    }
    
}

