//
//  LocalizationUtil.swift
//  TakeAPictureExample
//
//  Created by Chandnani, Harsh on 3/13/22.
//

import Foundation

var strTakePic = NSLocalizedString("take_pic", comment: "")
