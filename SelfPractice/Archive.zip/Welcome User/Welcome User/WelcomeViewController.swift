//
//  ViewController.swift
//  Welcome User
//
//  Created by Chandnani, Harsh on 1/30/22.
//

import UIKit

class WelcomeViewController: UIViewController {

    @IBOutlet weak var txtFirstName: UITextField!
    @IBOutlet weak var txtLastName: UITextField!
    @IBOutlet weak var lblWelcome: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func ProceedOnClickFuntion(_ sender: Any) {
        guard let firstName = txtFirstName.text, !firstName.isEmpty else {
            lblWelcome.text = "Please Enter First Name"
            return
        }
        guard let lastName = txtLastName.text, !lastName.isEmpty else {
            lblWelcome.text = "Please Enter Last Name"
            return
        }
        lblWelcome.text = "Hello \(firstName) \(lastName)"
    }
    
    
}

