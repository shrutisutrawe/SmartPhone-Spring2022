//
//  StockViewController.swift
//  StockMaster2
//
//  Created by Chandnani, Harsh on 3/10/22.
//

import UIKit
import SwiftUI
import SwiftyJSON
import SwiftSpinner
import Alamofire
import PromiseKit
import RealmSwift

class StockViewController: UIViewController{

    let stockArr = ["FB","TSLA","MSFT","AAPL"]
    
    var stockData: [QuoteShort] = []
    
    @IBOutlet weak var tblView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        print (Realm.Configuration.defaultConfiguration.fileURL!)
        loadStockData()
        // Do any additional setup after loading the view.
    }
    
    

}
