//
//  QuoteShort.swift
//  StockMaster2
//
//  Created by Chandnani, Harsh on 3/10/22.
//

import Foundation
class QuoteShort{

    var symbol : String = ""
    var price : Float = 0.0
    var volume : Int = 0

}
