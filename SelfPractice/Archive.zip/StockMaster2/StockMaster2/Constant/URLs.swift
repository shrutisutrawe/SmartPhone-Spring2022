//
//  URLs.swift
//  StockMaster2
//
//  Created by Chandnani, Harsh on 3/10/22.
//

import Foundation
let urlShortQuote = "https://financialmodelingprep.com/api/v3/quote-short/"
