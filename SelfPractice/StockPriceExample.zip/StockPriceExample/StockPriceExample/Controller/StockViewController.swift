//
//  StockViewController.swift
//  StockPriceExample
//
//  Created by Shravya Komarla Ramesh on 3/26/22.
//

import UIKit
import Alamofire
import SwiftyJSON
import SwiftSpinner

class StockViewController: UIViewController {

    @IBOutlet weak var lblStockPrice: UILabel!
    @IBOutlet weak var txtStockSymbol: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func getStockPrice(_ sender: Any) {
        
        guard let symbol = txtStockSymbol.text else {return}
        let url = "\(shortQuoteURL)\(symbol.uppercased())?apikey=\(apiKeys)"
        print(url)
        
        SwiftSpinner.show("Getting Stock Price")
        AF.request(url).responseJSON{ response in
            SwiftSpinner.hide(nil)
            if response.error != nil{
                print(response.error!)
                return
            }
            let stocks = JSON(response.data!).array
            
            guard let stock = stocks!.first else {return}
            
            let quote = QuoteShort()
            quote.symbol = stock["symbol"].stringValue
            quote.price = stock["price"].floatValue
            quote.volume = stock["volume"].intValue
            
            self.lblStockPrice.text = "\(quote.symbol) : \(quote.price) $"
        }
    }
    

}
