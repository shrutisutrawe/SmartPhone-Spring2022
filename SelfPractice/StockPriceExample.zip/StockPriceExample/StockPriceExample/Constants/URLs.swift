//
//  URLs.swift
//  StockPriceExample
//
//  Created by Shravya Komarla Ramesh on 3/26/22.
//

import Foundation

let shortQuoteURL = "https://financialmodelingprep.com/api/v3/quote-short/"
