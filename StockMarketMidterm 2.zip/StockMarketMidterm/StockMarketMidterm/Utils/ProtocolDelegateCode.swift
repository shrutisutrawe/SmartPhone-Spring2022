//
//  ProtocolDelegateCode.swift
//  StockMarketMidterm
//
//  Created by Chandnani, Harsh on 4/10/22.
//

import Foundation

protocol SendStockDelegate {
    func sendStockData(_ quoteShort : QuoteShort)
}

