//
//  URLFile.swift
//  StockMarketMidterm
//
//  Created by Chandnani, Harsh on 4/10/22.
//

import Foundation

let urlShortQuote = "https://financialmodelingprep.com/api/v3/quote/"
