//
//  ViewController.swift
//  BMICalculator
//
//  Created by Chandnani, Harsh on 5/3/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var btnLBS: UIButton!
    @IBOutlet weak var btnKGS: UIButton!
    @IBOutlet weak var btnFeet: UIButton!
    @IBOutlet weak var btnCms: UIButton!
    
    @IBOutlet weak var txtWeight: UITextField!
    @IBOutlet weak var txtHeight: UITextField!
    @IBOutlet weak var txtHeightInches: UITextField!
    
    @IBOutlet weak var lblOutputBMI: UILabel!
    
    var heightInFeet = true
    var weightInLbs = true
    
    var heightUnitSelected = false
    var weightUnitSelected = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func heightSelection(_ sender: UIButton) {
        
        if sender.tag == 3 {
            btnFeet.isSelected = true
            btnCms.isSelected = false
            heightInFeet = true
            txtHeightInches.isUserInteractionEnabled = true
            txtHeightInches.text = String(0)
            
        }
        else if sender.tag == 4 {
            btnFeet.isSelected = false
            btnCms.isSelected = true
            heightInFeet = false
            txtHeightInches.isUserInteractionEnabled = false
        }
        heightUnitSelected = true
        
    }
    @IBAction func weightSelection(_ sender: UIButton) {
        
        if sender.tag == 1{
            btnLBS.isSelected = true
            btnKGS.isSelected = false
            weightInLbs = true
            
        }
        else if sender.tag == 2{
            btnLBS.isSelected = false
            btnKGS.isSelected = true
            weightInLbs = false
        }
        weightUnitSelected = true
    }
    
    @IBAction func calculateBMIAction(_ sender: Any) {
        
        if(!weightUnitSelected){
            lblOutputBMI.text = "Please select unit for Weight";
            return
        }
        
        if(!heightUnitSelected){
            lblOutputBMI.text = "Please select unit for Height";
            return
        }
        
        
        var weight = Double(txtWeight.text!)
        
        if weight == nil {
            lblOutputBMI.text = "Please Enter weight"
            return
        }
        
        if(weightInLbs){
            weight = weight! * 0.45359237
        }
        
        
        var height = Double(txtHeight.text!)
        
        if height == nil {
            lblOutputBMI.text = "Please Enter height"
            return
        }
        
        if(heightInFeet){
            
            
            guard let htInches = Double(txtHeightInches.text!) else{ lblOutputBMI.text = "Please select unit options for Height/Weight"; return}
            
            height = height! * 0.3048 + (htInches * 0.0254)
        }else{
            txtHeightInches.text = String(0)
            height = height! / 100
        }
        
        var bmi = weight! / (height!*height!)
        
        if(bmi < 18.5){
            lblOutputBMI.text = String(bmi) + ": UnderWeight"
        }
        else if(bmi >= 18.5 && bmi <= 24.9){
            lblOutputBMI.text = String(bmi) + ": Healthy Weight"
        }
        else if(bmi >= 25 && bmi <= 29.9){
            lblOutputBMI.text = String(bmi) + ": Over Weight"
        }
        else if(bmi >= 30){
            lblOutputBMI.text = String(bmi) + ": Obese"
        }
        
        
    }
}

